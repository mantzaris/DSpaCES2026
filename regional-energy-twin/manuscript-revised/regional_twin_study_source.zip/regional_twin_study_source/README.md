# From Detail to Decisions in Regional Energy Twins

Authors: Alexander V. Mantzaris and James H. Korris.
This source package contains the clean revised manuscript (10 pages), its compiled
PDF, bibliography, IEEEtran template, generated tables, and PDF/SVG figure assets.
It is independent of the research repository. No raw data, experimental caches,
review markup, or external analysis inputs are needed to compile it.

Build from this directory:

```bash
bash build.sh
```

Requirements: a LaTeX distribution with latexmk, BibTeX, and the standard packages
amsmath, amssymb, amsthm, graphicx, booktabs, array, cite, balance, and hyperref.
The IEEEtran class and bibliography style are included. Sources were verified with
TeX Live 2019/Debian, pdfTeX 1.40.20 and latexmk 4.67. The build uses the supplied
numerical tables and figures; it does not rerun analysis or access the network.

`source_manifest.json` provides SHA-256 hashes of every packaged file other than
itself. The supplied PDF is byte-identical to the clean author-review PDF. PDF
metadata may differ when rebuilt with a different TeX installation.
